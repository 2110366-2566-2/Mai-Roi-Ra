DO $$ 
BEGIN
    -- Insert data into Reviews table
    INSERT INTO participate (user_id, event_id, num_participant, created_at, updated_at)
    VALUES 
    ('550e8400-e29b-41d4-a716-446655440100', '550e8400-e29b-41d4-a716-446655440400', 3, CURRENT_TIMESTAMP, NULL),
    ('550e8400-e29b-41d4-a716-446655440101', '550e8400-e29b-41d4-a716-446655440400', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP + interval '2 days'),
    ('550e8400-e29b-41d4-a716-446655440102', '550e8400-e29b-41d4-a716-446655440400', 2, CURRENT_TIMESTAMP, NULL);

EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error: %', SQLERRM;
END $$;