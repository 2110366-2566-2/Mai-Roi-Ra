package utils

// func assignToTrue(s *bool) bool {
// 	*s = true
// 	return *s
// }

// func assignToFalse(s *bool) bool {
// 	*s = false
// 	return *s
// }
